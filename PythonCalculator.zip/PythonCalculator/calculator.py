def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b

def get_number(prompt):
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print("Invalid input. Please enter a valid number.")

def get_operation():
    operations = {
        '+': ('Addition', add),
        '-': ('Subtraction', subtract),
        '*': ('Multiplication', multiply),
        '/': ('Division', divide)
    }
    
    print("\nAvailable operations:")
    for symbol, (name, _) in operations.items():
        print(f"  {symbol} - {name}")
    
    while True:
        operation = input("\nEnter operation (+, -, *, /): ").strip()
        if operation in operations:
            return operations[operation][1]
        print("Invalid operation. Please choose +, -, *, or /")

def calculate():
    print("=" * 50)
    print("Python Calculator")
    print("=" * 50)
    
    while True:
        try:
            num1 = get_number("\nEnter first number: ")
            operation = get_operation()
            num2 = get_number("Enter second number: ")
            
            result = operation(num1, num2)
            print(f"\nResult: {result}")
            
        except ValueError as e:
            print(f"\nError: {e}")
        except KeyboardInterrupt:
            print("\n\nCalculator terminated by user.")
            break
        except Exception as e:
            print(f"\nUnexpected error: {e}")
        
        print("\n" + "-" * 50)
        continue_calc = input("Perform another calculation? (y/n): ").strip().lower()
        if continue_calc != 'y':
            print("\nThank you for using the calculator. Goodbye!")
            break

if __name__ == "__main__":
    calculate()
