# Python Calculator

## Overview
A simple command-line calculator application written in Python that performs basic arithmetic operations (addition, subtraction, multiplication, division).

## Recent Changes
- **October 26, 2025**: Initial project setup
  - Created calculator.py with basic arithmetic functions
  - Implemented user-friendly CLI interface
  - Added error handling for invalid inputs and division by zero
  - Supports continuous calculation mode

## Project Architecture
- **calculator.py**: Main application file containing:
  - Arithmetic operation functions (add, subtract, multiply, divide)
  - Input validation and error handling
  - Interactive command-line interface
  - Continuous operation loop

## Features
- Basic arithmetic operations: +, -, *, /
- Support for decimal numbers
- Error handling for division by zero
- Input validation for numbers and operations
- Continuous calculation mode
- Clean, user-friendly interface

## Running the Calculator
```bash
python calculator.py
```

## User Preferences
None specified yet.
